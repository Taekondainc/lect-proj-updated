({
	appDir: "../",
	baseUrl: "js",
	dir: "../built",
	optimizeCss: "standard",
	modules: [
		{ name: "01-app" },
		{ name: "02-app" }
	]
})